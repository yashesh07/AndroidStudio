package main;

public class CurrentUser {

    public static String ID;
    public static String sqlPassword;
}
